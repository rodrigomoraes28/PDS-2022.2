
public class Indio {
	private String nome; 
	public Indio(String nome){ 
		this.nome = nome; 
	} 
	public String getNome() { 
		return nome; 
	} 
	public void setNome(String nome) { 
		this.nome = nome; 
	} 
}
